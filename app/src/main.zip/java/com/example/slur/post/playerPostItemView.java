package com.example.slur.post;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.slur.R;

public class playerPostItemView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_post_item_view);
    }
}