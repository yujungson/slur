package com.example.slur.post;

public interface CustomDialogListener {
    void onPositiveClicked(String name, String age, String addr);
    void onNegativeClicked();
}
