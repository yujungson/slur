package com.example.slur.post;

public class OwnerPosition {
    private String position;

    public OwnerPosition(String position) {
        this.position = position;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }
}
